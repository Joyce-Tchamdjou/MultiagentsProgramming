Travail effectué en binôme par Joyce Pascale Tchamdjou et Cyndy Noubissi.
Réponses qux questions dans le fichier .ipynb

Problème renconté avec mesa 

"RuntimeError : This event loop is already running" rencontrée sur Jupyter notebook et qui m'a fait perdre un temps considérable dans la réalisation du projet.